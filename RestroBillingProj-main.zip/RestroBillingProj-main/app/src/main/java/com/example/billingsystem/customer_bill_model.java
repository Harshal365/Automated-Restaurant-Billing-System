package com.example.billingsystem;

public class customer_bill_model {
    String s;

}
